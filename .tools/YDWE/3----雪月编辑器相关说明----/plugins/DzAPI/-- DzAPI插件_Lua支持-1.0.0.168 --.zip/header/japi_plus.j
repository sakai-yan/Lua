//设置可摧毁物位置
native DzDestructablePosition takes destructable d, real x, real y returns nothing

//设置单位位置-本地调用
native DzSetUnitPosition takes unit whichUnit, real x, real y returns nothing

//异步执行函数
native DzExecuteFunc takes string funcName returns nothing

//取鼠标指向的unit
native DzGetUnitUnderMouse takes nothing returns unit

//设置unit的贴图
native DzSetUnitTexture takes unit whichUnit, string path, integer texId returns nothing

//设置内存数值
native DzSetMemory takes integer address, real value returns nothing

//设置单位ID
native DzSetUnitID takes unit whichUnit, integer id returns nothing

//设置单位模型
native DzSetUnitModel takes unit whichUnit, string path returns nothing

//设置小地图背景图片
native DzSetWar3MapMap takes string map returns nothing

//获取war3语言
native DzGetLocale takes nothing returns string

//获取等级所需经验
native DzGetUnitNeededXP takes unit whichUnit, integer level returns integer

//释放字符串
native DzReleaseString takes string str returns nothing
